<div class="pt-3">
    <hr>
    <h2>Comments</h2>
    <br>
    <b class="p-2 d-block mb-2 text-left">Add New Comment</b>
    <input class="w-100 bg-light border-0 p-3" name="comment" placeholder="Press enter to post comment" spellcheck="false" style="outline:0">
    <hr>
</div>
