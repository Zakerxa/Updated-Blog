@props(['search'])
<div class="hero container">
    <div class="row d-flex align-items-center w-100">
        <div class="col-12 col-lg-3 text-center">
            <img src="/favicon.png" width="100%" alt="">
        </div>
        <div class="col-12 col-lg-8">
            <p>
                YaThaSone is the leading public service broadcaster in the world and YaThaSone is one of the biggest
                media site in Myanmar. YaThaSone Media Group was established on March, 2019.
            </p>
        </div>
    </div>
    @if ($search == 'yes')

    @endif
</div>
