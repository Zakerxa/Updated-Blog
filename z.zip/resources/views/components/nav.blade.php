<script>
    window.fbAsyncInit = function() {
            FB.init({
                appId: "503656240628058",
                xfbml: !0,
                version: "v8.0"
            }), FB.AppEvents.logPageView()
        },
        function(e, n, t) {
            var o, s = e.getElementsByTagName(n)[0];
            e.getElementById(t) || ((o = e.createElement(n)).id = t, o.src =
                "https://connect.facebook.net/en_US/sdk.js", s.parentNode.insertBefore(o, s))
        }(document, "script", "facebook-jssdk")
</script>
<script async defer src="https://connect.facebook.net/en_US/sdk.js" crossorigin="anonymous"></script>
<div id="fb-root"></div>
<script async defer src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.2"></script>


<nav class="navbar navbar-expand-lg border-bottom" style="background: #fff;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">YaThaSone Media</a>

        <div class="navbar-toggler" style="outline: none;border:0;" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </div>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="/about">About</a>
                </li>
            </ul>
            <ul class="navbar-nav m-0 mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Register</a>
                </li>
            </ul>
        </div>

    </div>
</nav>
