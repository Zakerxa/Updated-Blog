<x-layout>

    <x-hero search="no"></x-hero>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-8 pt-5 pb-5">
                <hr>
                <h3>About Us</h3>
                <p>
                    YaThaSone is the leading public service broadcaster in the world and YaThaSone is one of the biggest media
                    site in Myanmar. YaThaSone Media Group was established on March, 2019.
                </p>
                <hr>
                <h3> We do this across</h3>
                <p>
                    We're unbiased and self-sufficient, and every day we produce unique, world-class programming and content
                    that informs, educates, and entertains millions of people in Myanmar and throughout the world.
                </p>
            </div>
        </div>
    </div>
</x-layout>
