<x-layout>
    <x-hero search="yes"/>
    <x-blogs :blogs="$blogs" :populars="$populars"></x-blogs>
</x-layout>
