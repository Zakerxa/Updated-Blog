<div class="col-12 col-md-4 col p-1 order-md-0">
    <div class="dropdown">
        <button class="btn btn-outline-primary dropdown-toggle w-100" type="button" data-bs-toggle="dropdown"
            aria-expanded="false">
            <?php echo e(isset($currentcategory) ? $currentcategory->name : 'Filter By Categories'); ?>

        </button>
        <ul class="dropdown-menu">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a class="dropdown-item" href="/?categories=<?php echo e($category->slug); ?><?php echo e(request('search')?'&search='.request('search') : ''); ?>"><?php echo e($category->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/category-dropdown.blade.php ENDPATH**/ ?>