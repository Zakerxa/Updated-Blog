<div class="row">
   <div class="col-12">
      <h1 class="border-bottom p-3"> Latest Posts</h1>
   </div>
    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-md-6">
            <div class="m-1 card shadow">
                <img src="https://zakerxa.com/images/<?php echo e($blog->blog_id); ?>/<?php echo e($blog->pimg); ?>"
                    alt="">
                <div class="card-body">
                    <a href="/blog/<?php echo $blog->title; ?>">
                        <h5 class="card-title"><?php echo html_entity_decode($blog->title); ?></h5>
                    </a>
                    <a href="/categories/<?php echo e($blog->category->slug); ?>">
                        <p><?php echo e($blog->category->name); ?></p>
                    </a>
                    <p class="card-text"><?php echo e(Str::substr($blog->fcontent, 0, 75)); ?> ...</p>
                    <div class="row">
                        <div class="col">
                            <p class="card-text"><small
                                    class="text-muted"><?php echo e(\Carbon\Carbon::parse($blog->created_date)->diffForHumans()); ?></small>
                            </p>
                        </div>
                        <div class="col text-end">
                            <p class="card-text"><small class="text-muted"><?php echo e($blog->views); ?>

                                    views</small>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center text-muted p-5">
            <h5>There is no blog</h5>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/blog-sections.blade.php ENDPATH**/ ?>