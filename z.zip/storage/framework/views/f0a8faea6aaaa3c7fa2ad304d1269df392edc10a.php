<?php $attributes = $attributes->exceptProps(['currentcategory','categories']); ?>
<?php foreach (array_filter((['currentcategory','categories']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-8 p-1 order-md-1">
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-primary" type="submit">Search</button>
        </form>
    </div>
    <div class="col-12 col-md-4 col p-1 order-md-0">
        <div class="dropdown">
            <button class="btn btn-outline-primary dropdown-toggle w-100" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(isset($currentcategory) ? $currentcategory->name : 'Filter By Categories'); ?>

            </button>
            <ul class="dropdown-menu">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a class="dropdown-item" href="/categories/<?php echo e($category->name); ?>"><?php echo e($category->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/filter.blade.php ENDPATH**/ ?>