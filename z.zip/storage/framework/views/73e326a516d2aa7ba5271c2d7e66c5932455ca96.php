<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row p-0 m-0 justify-content-center">
        <div class="p-3">
            Home / <a href="/?categories=<?php echo e($blog->category->name); ?>"><?php echo e($blog->category->name); ?></a>
        </div>
        <div class="col-12 col-lg-7">
            <h3 class="p-1"><?php echo html_entity_decode($blog->title); ?></h3>
            <img src="https://zakerxa.com/images/<?php echo e($blog->blog_id); ?>/<?php echo e($blog->pimg); ?>" alt="" width="100%">
                <p class="pt-4"><?php echo $blog->fcontent; ?></p>
                <p><?php echo $blog->scontent; ?></p>
                <p><?php echo $blog->tcontent; ?></p>
                <p><?php echo $blog->focontent; ?></p>
                <p><?php echo $blog->ficontent; ?></p>
                <p><?php echo $blog->sicontent; ?></p>
                <p><?php echo $blog->secontent; ?></p>

                <div class="row">
                    <div class="col-12">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.comments','data' => []]); ?>
<?php $component->withName('comments'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
        </div>


        <div class="col-12 col-lg-4 offset-lg-1">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.rightside-blogs','data' => ['acceptor' => $relatives,'msg' => 'Relative']]); ?>
<?php $component->withName('rightside-blogs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['acceptor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($relatives),'msg' => 'Relative']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/single-blog.blade.php ENDPATH**/ ?>