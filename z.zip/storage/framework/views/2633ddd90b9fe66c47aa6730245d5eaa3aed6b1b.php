<?php $attributes = $attributes->exceptProps(['blogs', 'populars']); ?>
<?php foreach (array_filter((['blogs', 'populars']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>;

<div class="container">
    
    <div class="row justify-content-center">
        
        <div class="col-12 col-md-8 col-lg-8 p-1 order-md-1">
            <form action="" class="d-flex" role="search" method="get">
                <input name="search" value="<?php echo e(request('search')); ?>" class="form-control me-2" type="search"
                    placeholder="Search . . ." aria-label="Search">
                <?php if(request('categories')): ?>
                    <input type="hidden" name="categories" value="<?php echo e(request('categories')); ?>">
                <?php endif; ?>
                <button class="btn btn-primary" type="submit">Search</button>
            </form>
        </div>
        
        <?php if (isset($component)) { $__componentOriginal4f66722947691db01920253e9e2edd1fa3282e1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CategoryDropdown::class, []); ?>
<?php $component->withName('category-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f66722947691db01920253e9e2edd1fa3282e1d)): ?>
<?php $component = $__componentOriginal4f66722947691db01920253e9e2edd1fa3282e1d; ?>
<?php unset($__componentOriginal4f66722947691db01920253e9e2edd1fa3282e1d); ?>
<?php endif; ?>
    </div>

    
    <div class="row justify-content-center pt-4 pb-4">
        <div class="col-12 col-md-8 pb-5">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.latest-blogs','data' => ['blogs' => $blogs]]); ?>
<?php $component->withName('latest-blogs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['blogs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blogs)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <div class="row pt-4">
                <div class="col-12">
                    <?php echo e($blogs->onEachSide(1)->links()); ?>

                </div>
            </div>
        </div>
        <div class="col-12 col-md-4 pb-5">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.rightside-blogs','data' => ['acceptor' => $populars,'msg' => 'Popular']]); ?>
<?php $component->withName('rightside-blogs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['acceptor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($populars),'msg' => 'Popular']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="row">

    </div>

</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/blogs.blade.php ENDPATH**/ ?>