<div class="row">
    <div class="col-12">
        <h1 class="border-bottom p-3"> Popular Posts</h1>
     </div>
    <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="m-1 card shadow">
                <img src="https://zakerxa.com/images/<?php echo e($popular->blog_id); ?>/<?php echo e($popular->pimg); ?>" alt="">
                <div class="card-body">
                    <a href="/blog/<?php echo $popular->title; ?>">
                        <h5 class="card-title"><?php echo html_entity_decode($popular->title); ?></h5>
                    </a>
                    <a href="/categories/<?php echo e($popular->category->slug); ?>">
                        <p><?php echo e($popular->category->name); ?></p>
                    </a>
                    <p class="card-text"><?php echo e(Str::substr($popular->fcontent, 0, 75)); ?> ...</p>
                    <div class="row">
                        <div class="col">
                            <p class="card-text"><small
                                    class="text-muted"><?php echo e(\Carbon\Carbon::parse($popular->created_date)->diffForHumans()); ?></small>
                            </p>
                        </div>
                        <div class="col text-end">
                            <p class="card-text"><small class="text-muted"><?php echo e($popular->views); ?> views</small>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/popular.blade.php ENDPATH**/ ?>