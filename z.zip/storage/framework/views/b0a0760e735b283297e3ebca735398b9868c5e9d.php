<?php $attributes = $attributes->exceptProps(['search']); ?>
<?php foreach (array_filter((['search']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="hero container">
    <div class="row d-flex align-items-center w-100">
        <div class="col-12 col-lg-3 text-center">
            <img src="/favicon.png" width="100%" alt="">
        </div>
        <div class="col-12 col-lg-8">
            <p>
                YaThaSone is the leading public service broadcaster in the world and YaThaSone is one of the biggest
                media site in Myanmar. YaThaSone Media Group was established on March, 2019.
            </p>
        </div>
    </div>
    <?php if($search == 'yes'): ?>

    <?php endif; ?>
</div>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/hero.blade.php ENDPATH**/ ?>