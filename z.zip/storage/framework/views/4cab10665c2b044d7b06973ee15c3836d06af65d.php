<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <img src="https://zakerxa.com/images/<?php echo e($blog->blog_id); ?>/<?php echo e($blog->pimg); ?>" alt="">
            <h5><?php echo html_entity_decode($blog->title); ?></h5>
            <p><?php echo e($blog->category->name); ?></p>
            <p><?php echo $blog->fcontent; ?></p>
            <p><?php echo $blog->scontent; ?></p>
            <p><?php echo $blog->tcontent; ?></p>
            <p><?php echo $blog->focontent; ?></p>
            <p><?php echo $blog->ficontent; ?></p>
            <p><?php echo $blog->sicontent; ?></p>
            <p><?php echo $blog->secontent; ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/zakerxa/public_html/blogs/resources/views/components/blog.blade.php ENDPATH**/ ?>